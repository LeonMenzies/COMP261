package Core;
public class RobotInterruptedException extends RuntimeException{}
